declare const __uiFiles__: {
  ui: string
} 